.. index:: Subversion
.. _install-subversion:

===================
Trac and Subversion
===================

.. _install-subversion-bindings:

Bindings
========