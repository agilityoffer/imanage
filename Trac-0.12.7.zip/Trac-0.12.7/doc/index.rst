================================
Welcome to Trac's documentation!
================================

:Release: |version|
:Date: |today|

Contents:

.. toctree::
   :maxdepth: 1
   
   guide/index.rst
   admin/index.rst
   install/index.rst
   api/env
   dev/testing.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

