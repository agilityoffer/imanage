:mod:`trac.env` -- Trac Environment model and APIs
==================================================

.. module:: trac.env
    :synopsis: Trac Environment model and related APIs.
.. moduleauthor:: Jonas Borgström <jonas@edgewall.com>

.. autoclass:: IEnvironmentSetupParticipant
    :members: