.. _admin-ini:

===========================
The Trac Configuration File
===========================