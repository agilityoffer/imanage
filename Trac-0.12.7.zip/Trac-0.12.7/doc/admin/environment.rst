.. _admin-environment:

====================
The Trac Environment
====================

.. _admin-environment-database: