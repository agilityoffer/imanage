from trac.prefs.tests.functional import functionalSuite
