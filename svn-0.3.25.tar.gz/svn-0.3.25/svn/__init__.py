__version__ = '0.3.25'
(T_URL, T_PATH) = ('url', 'path')
